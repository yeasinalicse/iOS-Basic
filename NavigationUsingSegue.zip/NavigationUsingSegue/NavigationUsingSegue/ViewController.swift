//
//  ViewController.swift
//  NavigationUsingSegue
//
//  Created by Pridesys on 2/9/19.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

