//
//  BorderButton.swift
//  AppSwoosh
//
//  Created by Yeasin on 2/13/19.
//

import UIKit

class BorderButton: UIButton {

    override func awakeFromNib(){
        super.awakeFromNib()
        layer.borderWidth = 2.0
        layer.borderColor =
            UIColor.white.cgColor
    }

}
