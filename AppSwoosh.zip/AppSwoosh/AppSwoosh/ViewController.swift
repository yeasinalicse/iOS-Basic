//
//  ViewController.swift
//  AppSwoosh
//
//  Created by Pridesys on 2/13/19.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

